#include <stdio.h>
#include <string.h>

#include "threads/init.h"
#include "threads/malloc.h"
#include "threads/synch.h"
#include "threads/thread.h"

#include "devices/timer.h"

const int Default = 0;

int control;
int priority = 0;
void* aux;

//철광석, 구리, 필요 철광석, 필요구리, 철주괴, 구리주괴, 동철합금
int F;
int C;
int FF;
int CC;
int mdF=0;
int mdC=0;
int CF=0;
int x; //총 철광석 개수
int y; // 총 구리 개수
int readyF = 0; // 마지막 화로에 있는 철주괴
int readyC = 0; // 마지막 화로에 있는 구리주괴

int wait = 0;

//컨테이너 변수
int T1[3];
int T2[3];
int T3[3];
int T4[3];

//화로 변수
int FT1;
int FT2; 
int FT3[2];

//도식화를 위한 배열
int arr1[10] = { 0, };
int arr2[10] = { 0, };


struct semaphore BT1;
struct semaphore* pBT1;
struct semaphore BT2;
struct semaphore* pBT2;
struct semaphore BT3;
struct semaphore* pBT3;
struct semaphore BT4;
struct semaphore* pBT4;

struct semaphore RA1;
struct semaphore* pRA1;
struct semaphore RA2;
struct semaphore* pRA2;
struct semaphore RA3;
struct semaphore* pRA3;
struct semaphore RA4;
struct semaphore* pRA4;
struct semaphore RA5;
struct semaphore* pRA5;
struct semaphore RA6;
struct semaphore* pRA6;

struct semaphore IF1;
struct semaphore* pIF1;
struct semaphore IF2;
struct semaphore* pIF2;
struct semaphore IF3;
struct semaphore* pIF3;

void impleIF3();
void impleRA5();
void impleRA6();
void impleBT3();
void impleBT4();
void impleRA3();
void impleRA4();
void impleIF1();
void impleIF2();
void impleRA1();
void impleRA2();
void impleBT1();
void impleBT2();
void draw();


void run_factorii(char **argv){

        pBT1=&BT1;
        pBT2=&BT2;
        pBT3=&BT3;
        pBT4=&BT4;
        pRA1=&RA1;
        pRA2=&RA2;
        pRA3=&RA3;
        pRA4=&RA4;
        pRA5=&RA5;
        pRA6=&RA6;
        pIF1=&IF1;
        pIF2=&IF2;
        pIF3=&IF3;
        
        printf("implement factoriis !\n");

        sema_init (pBT1, control);
        sema_init (pBT2, control);
        sema_init (pBT3, control);
        sema_init (pBT4, control);
        sema_init (pRA1, control);
        sema_init (pRA2, control);
        sema_init (pRA3, control);
        sema_init (pRA4, control);
        sema_init (pRA5, control);
        sema_init (pRA6, control);
        sema_init (pIF1, control);
        sema_init (pIF2, control);
        sema_init (pIF3, control);

        thread_create ("tIF3", Default, impleIF3, aux);
        thread_create ("tRA5", Default, impleRA5, aux);
        thread_create ("tRA6", Default, impleRA6, aux);
        thread_create ("tBT3", Default, impleBT3, aux);
        thread_create ("tBT4", Default, impleBT4, aux);
        thread_create ("tRA3", Default, impleRA3, aux);
        thread_create ("tRA4", Default, impleRA4, aux);
        thread_create ("tIF1", Default, impleIF1, aux);
        thread_create ("tIF2", Default, impleIF2, aux);
        thread_create ("tRA1", Default, impleRA1, aux);
        thread_create ("tRA2", Default, impleRA2, aux);
        thread_create ("tBT1", Default, impleBT1, aux);
        thread_create ("tBT2", Default, impleBT2, aux);

        F =atoi(argv[1]); 
        C =atoi(argv[2]); 
        FF =atoi(argv[3]); 
        CC =atoi(argv[4]);
        
        for(int i=0;i<3;i++){
                arr1[i] = T1[i];
                arr2[i] = T2[i];
                arr1[i+6] = T3[i];
                arr2[i+6] = T4[i];
        }
        arr1[4] = FT1;
        arr2[4] = FT2; 
        
}

void impleIF3() {
        while(1){
                if(pIF3->value == 0 ){
                        sema_up(pIF3);
                }
                sema_down(pIF3);

                draw();

                //master 제조
                if(readyC >= CC && readyF >= FF){
                        wait += 1;
                        if(wait ==4){
                                readyC -= CC;
                                readyF -= FF;
                                mdC -= CC;
                                mdF -= FF;
                                CF+=1;
                                wait = 0;

                                if(x+mdF < FF || y+mdC < CC ){
                                        printf("Cannot Make CoFeIng Any More\n");
                                        printf("LEFT:  FeOre=%d,  CoOre=%d,  FeIng=%d,  CoIng=%d \nMADE:  CoFe=%d \n\n",x,y,mdF,mdC,CF);
                                        thread_exit();
                                }
                        }
                }


                sema_up(pRA5);
                sema_down(pIF3);
        }        
}

void impleRA5(){
         while(1){
                 if(pRA5->value == 0 ){
                        sema_up(pRA5);
                }
                sema_down(pRA5);

                if(T3[2] == 2 && wait == 0 ){
                        T3[2] = 0;
                        readyF +=1;
                }
                
                sema_up(pRA6);
                sema_down(pRA5);
        }

}

void impleRA6(){
         while(1){
                if(pRA6->value == 0 ){
                        sema_up(pRA6);
                }
                sema_down(pRA6);
        

                if(T4[2] == 2 && wait == 0){
                        T4[2] = 0;
                        readyC += 1;
                }
                
                sema_up(pBT3);
                sema_down(pRA6);
        }
}

void impleBT3(){
         while(1){
                if(pBT3->value == 0 ){
                                sema_up(pBT3);
                        }
                        sema_down(pBT3);
                 
                //주괴 이동(멈춤 고려) + 주괴빼내기
                if(FT3[0] < FF ){
                        if(T3[2] != 2){
                                if(T3[1] == 2){
                                        T3[2]=2;
                                        T3[1] = 0;}
                        }
                        if(T3[0] == 2){
                                T3[1] = 2;
                                T3[0] = 0;}
                 }
                 else;
                 
                sema_up(pBT4);
                sema_down(pBT3);
        }

}

void impleBT4(){
         while(1){
                if(pBT4->value == 0 ){
                        sema_up(pBT4);
                }
                sema_down(pBT4);

                 //주괴 이동(멈춤 고려) + 주괴빼내기
                 if(FT3[1] < CC){
                        if(T4[2] != 2){
                                if(T4[1] == 2){
                                        T4[2]=2;
                                        T4[1] = 0;}
                        }
                        if(T4[0] == 2){
                                T4[1] = 2;
                                T4[0] = 0;}
                 }
                 else;
 
                sema_up(pRA3);
                sema_down(pBT4);
        }

}

void impleRA3(){
         while(1){
                 if(pRA3->value == 0 ){
                        sema_up(pRA3);
                }
                sema_down(pRA3);

                if(FT1 == 2){
                        FT1 = 0;
                        T3[0] = 2;
                }
                else;
                
                sema_up(pRA4);
                sema_down(pRA3);     
        }

}

void impleRA4(){
         while(1){
                if(pRA4->value == 0 ){
                        sema_up(pRA4);
                }
                sema_down(pRA4);

                if(FT2 == 2){
                        FT2 = 0;
                        T4[0] = 2;
                }
                else;

                sema_up(pIF1);
                sema_down(pRA4);
        }

}

void impleIF1(){
         while(1){
                 if(pIF1->value == 0 ){
                        sema_up(pIF1);
                }
                sema_down(pIF1);
                 
                 if(FT1 == 1){
                        FT1 = 2;
                        mdF += 1;
                 }
                 
                sema_up(pIF2);
                sema_down(pIF1);
      
         }
}

void impleIF2(){
         while(1){
                 if(pIF2->value == 0 ){
                        sema_up(pIF2);
                }
                sema_down(pIF2);
                
                if(FT2 == 1){
                        FT2 = 2;
                        mdC+=1;
                 }
                 
                sema_up(pRA1);
                sema_down(pIF2);
        }

}

void impleRA1(){
         while(1){
                 if(pRA1->value == 0 ){
                        sema_up(pRA1);
                }
                sema_down(pRA1);

                if(FT1 != 1 && FT1 != 2){
                        if(T1[2] == 1){
                                FT1 = 1;
                                T1[2] = 0;
                        }
                }
                else;
                
 
                sema_up(pRA2);
                sema_down(pRA1);
                
        }

}

void impleRA2(){
         while(1){
                 if(pRA2->value == 0 ){
                        sema_up(pRA2);
                }
                sema_down(pRA2);

                //광석 옮기기
                if(FT2 != 1 && FT2 != 2){
                        if(T2[2] == 1){
                                FT2 = 1;
                                T2[2] = 0;
                        }
                }
                else;

                sema_up(pBT1);
                sema_down(pRA2);
                   
        }
}

void impleBT1(){
         while(1){
                 if(pBT1->value == 0 ){
                        sema_up(pBT1);
                }
                sema_down(pBT1);                 
                        
                //철광석 이동(멈춤 고려) + 철광석 떨어뜨리기
                if(T1[2] == 0){
                        if(T1[1] == 1){
                                T1[2]=1;
                                T1[1] = 0;}

                        if(T1[0] == 1){
                                T1[1] = 1;
                                T1[0] = 0;}
                        if(F>0){
                                T1[0] = 1;
                                F -= 1;
                        }
                 }
                 else;

                sema_up(pBT2);
                sema_down(pBT1);
                
        }
}

void impleBT2(){
         while(1){
                 if(pBT2->value == 0 ){
                        sema_up(pBT2);
                }
                sema_down(pBT2);

                 //철광석 이동(멈춤 고려) + 철광석 떨어뜨리기
                if(T2[2] == 0){
                        if(T2[1] == 1){
                                T2[2]=1;
                                T2[1] = 0;}

                        if(T2[0] == 1){
                                T2[1] = 1;
                                T2[0] = 0;}
                        
                        if(C > 0){
                                T2[0] = 1;
                                C -= 1;
                        }
                 }
                 else;

 
                sema_up(pIF3);
                sema_down(pBT2);
                timer_sleep(100);
                
        }

}

void draw()
{

        for(int i=0;i<3;i++){
                arr1[i] = T1[i];
                arr2[i] = T2[i];
                arr1[i+6] = T3[i];
                arr2[i+6] = T4[i];
        }
        arr1[4] = FT1;
        arr2[4] = FT2;        

        //
        printf("|  ");
        for(int i=0; i<10; i++){
                printf("X  |  ");
        }

        printf("\n");

        //
        printf("|");
        for(int i=0; i<10; i++){
                if(i == 3 || i==5 || i==9){
                        printf("  @  |");
                        continue;
                }

                if(arr1[i] == 0){
                        if(i == 4) printf("  -  ");
                        else printf("     ");
                }
                else if(arr1[i] == 1){
                        printf("  ㅇ ");}
                else if(arr1[i]==2){
                        printf("  i  ");}
                printf("|");                              
        }
        printf("\n");

        //
        printf("|  ");
        for(int i=0; i<9; i++){
                printf("X  |  ");}
        printf("-  |");
        printf("\n");

        //
        printf("|");
        for(int i=0; i<10; i++){
                if(i == 3 || i==5 || i==9){
                        printf("  @  |");
                        continue;
                }

                if(arr2[i] == 0){
                        if(i == 4) printf("  -  ");
                        else printf("     ");
                }
                else if(arr2[i] == 1){
                        printf("  ㅇ ");}
                else if(arr2[i]==2){
                        printf("  i  ");}
                printf("|");                              
        }
        printf("\n");
        
        //
        printf("|  ");
        for(int i=0; i<10; i++){
                printf("X  |  ");
        }
        x = F+T1[0]+T1[1]+T1[2]; //x : 철광석 개수
        if(FT1 == 1){
                x+=1;
        }
        y = C+T2[0]+T2[1]+T2[2]; //x : 철광석 개수
        if(FT2 == 1){
                y+=1;
        }


        printf("\n");
        printf("LEFT:  FeOre=%d,  CoOre=%d,  FeIng=%d,  CoIng=%d \nMADE:  CoFe=%d",x,y,mdF,mdC,CF);
        printf("\n");
        printf("\n");
        
}
